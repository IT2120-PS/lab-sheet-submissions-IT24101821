## Part 1
## Setting Directory
setwd("C:\\Users\\it24101821\\Desktop\\IT24101821")

## Importing the data set
data <- read.table("DATA 4.txt", header = TRUE, sep = " ")

## View the file in a separate window
fix(data)

## Attach the file into R. So, you can call the variables by their names.
attach(data)


## Part 2
## Part (a)

## Obtaining Box Plots
boxplot(X1, main = "Box plot for Team Attendance", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X2, main = "Box plot for Team Salary", outline = TRUE, outpch = 8, horizontal = TRUE)
boxplot(X3, main = "Box plot for Years", outline = TRUE, outpch = 8, horizontal = TRUE)

## Obtaining Histogram
hist(X1, ylab = "Frequency", xlab = "Team Attendance", main = "Histogram for Team Attendance")
hist(X2, ylab = "Frequency", xlab = "Team Salary", main = "Histogram for Team Salary")
hist(X3, ylab = "Frequency", xlab = "Years", main = "Histogram for Years")

## Stem & Leaf Plot
stem(X1)
stem(X2)
stem(X3)


## Part (b)

## Mean
mean(X1)
mean(X2)
mean(X3)

## Median
median(X1)
median(X2)
median(X3)

## Standard Deviation
sd(X1)
sd(X2)
sd(X3)


# Getting five number summary along with mean value
summary(X1)
summary(X2)
summary(X3)

# Getting only five number summary for X1 variable
quantile(X1)

# Calling first Quartile of X1 using index value
quantile(X1)[2]

# Calling third Quartile of X1 using index value
quantile(X1)[4]


# Obtaining Inter Quartile Range (IQR) of each variable
IQR(X1)
IQR(X2)
IQR(X3)


# Function to get the mode of a data set
get.mode <- function(y) {
  counts <- table(y) 
  names(counts[counts == max(counts)])
}

# Getting the mode of a variable using the function defined above 
get.mode(data$Years)

# Printing how each command finds the function works 
counts <- table(data$Years)           # Frequency table for the variable
counts                                # Display frequency table
max(counts)                           # Maximum frequency
counts == max(counts)                 # Logical check for maximum frequency
names(counts[counts == max(counts)])  # Names with maximum frequency


# Function to check the existence of outliers in a data set
get.outliers <- function(x) {
  q1 <- quantile(x)[2]
  q3 <- quantile(x)[4]
  iqr <- q3 - q1
  lb <- q1 - 1.5 * iqr
  ub <- q3 + 1.5 * iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(c(x[x < lb | x > ub])), collapse = ",")))
}

# Checking the outliers of variables using the function
get.outliers(X1)
get.outliers(X2)
get.outliers(X3)


# Calculate the interval for outliers
q1 <- quantile(x)[2]
q3 <- quantile(x)[4]
iqr <- q3 - q1
lb <- q1 - 1.5 * iqr
ub <- q3 + 1.5 * iqr

# Print upper and lower bounds
print(paste("Upper Bound = ", ub))
print(paste("Lower Bound = ", lb))

# Print outliers if they exist
print(paste("Outliers:", paste(sort(c(x[x < lb | x > ub])), collapse = ",")))


setwd("C:\\Users\\it24101821\\Desktop\\IT24101821")
#1
branch_data <- read.table("Exercise.txt",header=TRUE,sep=",")

#2
attach(branch_data)
for(col in names(branch_data)){
  print(paste(col,":",class(branch_data[[col]])))
}
#Branch: Nominal
#Sales: Nominal/Ratio
#Advertising:Nominal/Ratio
#Years:Nominal/Ratio

#3
boxplot(branch_data$Sales_X1, Main="Sales",outline=TRUE, outpch=8, horizontal=TRUE,
        xlab="Sales")
hist(branch_data$Sales_X1, Main="Sales",outline=TRUE,outpch=8, horizontal=TRUE)

#4
summary(Advertising_X2)
IQR(Advertising_X2)

#5
get.outlier <-function(x){
  q1<-quantile(x)[2]
  q3<-quantile(x)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers =", paste(sort(x[x<lb | x>ub]),collapse=",")))
}
get.outlier(Years_X3)
